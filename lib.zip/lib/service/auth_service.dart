// lib/service/auth_service.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../const/app_constatnts.dart';
import '../model/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ─── Email Sign Up ────────────────────────────────────────────────
  Future<String?> signUp({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      final result = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      if (result.user != null) {
        // Send verification email
        await result.user!.sendEmailVerification();
        await result.user!.updateDisplayName(name.trim());

        // Save user to Firestore
        final userData = {
          'uid': result.user!.uid,
          'name': name.trim(),
          'email': email.trim(),
          'photoUrl': '',
          'isOnline': false,
          'emailVerified': false,
          'lastSeen': Timestamp.fromDate(DateTime.now()),
          'status': '👋 Hey there! I am using Wavechat.',
        };
        await _firestore
            .collection(AppConstants.usersCollection)
            .doc(result.user!.uid)
            .set(userData);

        return null; // null = success
      }
      return 'Sign up failed';
    } on FirebaseAuthException catch (e) {
      return _handleError(e);
    }
  }

  // ─── Email Sign In ────────────────────────────────────────────────
  Future<String?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final result = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      if (result.user == null) return 'Sign in failed';

      // ✅ Block unverified email users
      if (!result.user!.emailVerified) {
        await _auth.signOut();
        return 'Please verify your email first. Check your inbox for a verification link.';
      }

      await _syncUserToFirestore(result.user!);
      return null; // null = success
    } on FirebaseAuthException catch (e) {
      return _handleError(e);
    }
  }

  // ─── Google Sign In ───────────────────────────────────────────────
  Future<String?> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return 'Google sign in cancelled';

      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final result = await _auth.signInWithCredential(credential);
      if (result.user == null) return 'Google sign in failed';

      // Google accounts are pre-verified
      await _syncUserToFirestore(result.user!, isGoogleUser: true);
      return null;
    } on FirebaseAuthException catch (e) {
      return _handleError(e);
    } catch (e) {
      return e.toString();
    }
  }

  // ─── Sync user doc to Firestore ───────────────────────────────────
  Future<void> _syncUserToFirestore(User user, {bool isGoogleUser = false}) async {
    final doc = await _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .get();

    if (doc.exists) {
      // Update online status and verification
      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.uid)
          .set({
        'isOnline': true,
        'emailVerified': isGoogleUser ? true : user.emailVerified,
        'lastSeen': Timestamp.fromDate(DateTime.now()),
      }, SetOptions(merge: true));
    } else {
      // Create new doc (for Google users on first sign in)
      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.uid)
          .set({
        'uid': user.uid,
        'name': user.displayName ?? user.email?.split('@')[0] ?? 'User',
        'email': user.email ?? '',
        'photoUrl': user.photoURL ?? '',
        'isOnline': true,
        'emailVerified': isGoogleUser ? true : user.emailVerified,
        'lastSeen': Timestamp.fromDate(DateTime.now()),
        'status': '👋 Hey there! I am using Wavechat.',
      });
    }
  }

  // ─── Resend verification email ────────────────────────────────────
  Future<String?> resendVerificationEmail() async {
    try {
      await _auth.currentUser?.sendEmailVerification();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  // ─── Reset Password ───────────────────────────────────────────────
  Future<String?> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
      return null;
    } on FirebaseAuthException catch (e) {
      return _handleError(e);
    }
  }

  // ─── Sign Out ─────────────────────────────────────────────────────
  Future<void> signOut() async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid != null) {
        await _firestore
            .collection(AppConstants.usersCollection)
            .doc(uid)
            .set({
          'isOnline': false,
          'lastSeen': Timestamp.fromDate(DateTime.now()),
        }, SetOptions(merge: true));
      }
    } catch (_) {}
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  Future<void> updateOnlineStatus(bool isOnline) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.isEmpty) return;
    await _firestore
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .set({
      'isOnline': isOnline,
      'lastSeen': Timestamp.fromDate(DateTime.now()),
    }, SetOptions(merge: true));
  }

  // ─── Error handler ────────────────────────────────────────────────
  String _handleError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'email-already-in-use':
        return 'An account already exists with this email.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      default:
        return e.message ?? 'An error occurred. Please try again.';
    }
  }
}