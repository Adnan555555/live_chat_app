// lib/screens/auth/verify_email_screen.dart
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:get/get.dart';
import '../../const/app_constatnts.dart';
import '../../controller/auth_controller.dart';
import '../../service/notification_service.dart';
import '../home/home_screen.dart';
import 'login_screen.dart';

class VerifyEmailScreen extends StatefulWidget {
  const VerifyEmailScreen({super.key});

  @override
  State<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  Timer? _checkTimer;
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    // Poll every 3 seconds to check if email was verified
    _checkTimer = Timer.periodic(const Duration(seconds: 3), (_) => _checkVerified());
  }

  @override
  void dispose() {
    _checkTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkVerified() async {
    await _auth.currentUser?.reload();
    if (_auth.currentUser?.emailVerified == true) {
      _checkTimer?.cancel();
      await NotificationService().initialize();
      Get.offAll(() => const HomeScreen());
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AuthController>();
    final email = _auth.currentUser?.email ?? '';

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 60),

              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: AppTheme.secondary.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: AppTheme.secondary.withOpacity(0.3), width: 2),
                ),
                child: const Icon(Icons.mark_email_unread_outlined,
                    color: AppTheme.secondary, size: 48),
              ).animate().scale(
                begin: const Offset(0.5, 0.5),
                duration: 600.ms,
                curve: Curves.elasticOut,
              ),

              const SizedBox(height: 32),

              const Text(
                'Verify Your Email',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                ),
              ).animate().fadeIn(delay: 200.ms),

              const SizedBox(height: 12),

              Text(
                'We sent a verification link to:\n$email',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 15, height: 1.5),
              ).animate().fadeIn(delay: 300.ms),

              const SizedBox(height: 16),

              const Text(
                'Check your inbox and click the link to verify your account. This page will update automatically.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppTheme.textSecondary, fontSize: 13, height: 1.6),
              ).animate().fadeIn(delay: 400.ms),

              const SizedBox(height: 48),

              // Checking indicator
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppTheme.secondary.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text('Waiting for verification...',
                      style: TextStyle(
                          color: AppTheme.textSecondary, fontSize: 13)),
                ],
              ).animate().fadeIn(delay: 500.ms),

              const SizedBox(height: 40),

              // Resend button
              Obx(() => SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: controller.isLoading.value
                      ? null
                      : controller.resendVerification,
                  child: controller.isLoading.value
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                        color: AppTheme.primary, strokeWidth: 2.5),
                  )
                      : const Text('Resend Verification Email'),
                ),
              )).animate().fadeIn(delay: 600.ms),

              const SizedBox(height: 16),

              TextButton(
                onPressed: () async {
                  await _auth.signOut();
                  Get.offAll(() => const LoginScreen());
                },
                child: const Text('Back to Sign In',
                    style: TextStyle(color: AppTheme.textSecondary)),
              ).animate().fadeIn(delay: 650.ms),
            ],
          ),
        ),
      ),
    );
  }
}
