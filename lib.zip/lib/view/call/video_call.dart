// lib/screens/chat/video_call_screen.dart
import 'package:flutter/material.dart';
import '../../const/app_constatnts.dart';
import '../../model/user_model.dart';
import '../../utils/user_avtar.dart';

class VideoCallScreen extends StatefulWidget {
  final UserModel otherUser;

  const VideoCallScreen({super.key, required this.otherUser});

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  bool _isMuted = false;
  bool _isCameraOff = false;
  bool _isFrontCamera = true;
  int _seconds = 0;
  late final _timer = Stream.periodic(const Duration(seconds: 1), (i) => i)
      .listen((_) => setState(() => _seconds++));

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String get _duration {
    final m = _seconds ~/ 60;
    final s = _seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Remote video placeholder
          Container(
            width: double.infinity,
            height: double.infinity,
            color: const Color(0xFF0D1B2A),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                UserAvatar(
                    user: widget.otherUser,
                    size: 120,
                    showOnlineIndicator: false),
                const SizedBox(height: 16),
                Text(widget.otherUser.name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Text(_duration,
                    style: const TextStyle(
                        color: AppTheme.secondary, fontSize: 15)),
              ],
            ),
          ),

          // Local camera preview placeholder (top right)
          Positioned(
            top: 60,
            right: 16,
            child: Container(
              width: 100,
              height: 140,
              decoration: BoxDecoration(
                color: _isCameraOff
                    ? Colors.grey[900]
                    : const Color(0xFF1A2E42),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.secondary, width: 2),
              ),
              child: _isCameraOff
                  ? const Icon(Icons.videocam_off,
                  color: Colors.white54, size: 32)
                  : const Icon(Icons.person, color: Colors.white54, size: 40),
            ),
          ),

          // Controls at bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(30, 20, 30, 50),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _VideoCallButton(
                    icon: _isMuted ? Icons.mic_off : Icons.mic,
                    onTap: () => setState(() => _isMuted = !_isMuted),
                    active: !_isMuted,
                  ),
                  _EndVideoCallButton(onTap: () => Navigator.pop(context)),
                  _VideoCallButton(
                    icon: _isCameraOff ? Icons.videocam_off : Icons.videocam,
                    onTap: () => setState(() => _isCameraOff = !_isCameraOff),
                    active: !_isCameraOff,
                  ),
                  _VideoCallButton(
                    icon: Icons.flip_camera_ios_rounded,
                    onTap: () =>
                        setState(() => _isFrontCamera = !_isFrontCamera),
                    active: true,
                  ),
                ],
              ),
            ),
          ),

          // Back button
          Positioned(
            top: 50,
            left: 16,
            child: SafeArea(
              child: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_ios_rounded,
                    color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VideoCallButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;

  const _VideoCallButton(
      {required this.icon, required this.onTap, required this.active});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          color: active
              ? Colors.white.withOpacity(0.2)
              : Colors.white.withOpacity(0.05),
          shape: BoxShape.circle,
          border: Border.all(
              color: active ? Colors.white38 : Colors.white12),
        ),
        child: Icon(icon,
            color: active ? Colors.white : Colors.white38, size: 24),
      ),
    );
  }
}

class _EndVideoCallButton extends StatelessWidget {
  final VoidCallback onTap;

  const _EndVideoCallButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 66,
        height: 66,
        decoration: const BoxDecoration(
          color: AppTheme.error,
          shape: BoxShape.circle,
        ),
        child: const Icon(Icons.call_end_rounded,
            color: Colors.white, size: 30),
      ),
    );
  }
}